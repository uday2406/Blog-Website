<?php
$con=mysqli_connect('localhost','root','','blog');
// if($con==true)
// {
//     echo "True";
// }
// else
// {
//     echo "False";
// }
?>