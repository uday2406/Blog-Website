<?php
    include_once('user_header.php');
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <!-- <h5 class="card-title">Special title treatment</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
                    <a href="UserProfile.php" class="btn btn-primary btn-lg">User Profile</a>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <!-- <h5 class="card-title">Special title treatment</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
                    <a href="PostBlog.php" class="btn btn-secondary btn-lg">Post A Blog</a>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <!-- <h5 class="card-title">Special title treatment</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
                    <a href="ViewBlogs.php" class="btn btn-success btn-lg">View Blogs</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
        include_once('user_footer.php');
       ?>